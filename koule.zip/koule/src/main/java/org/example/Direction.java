package org.example;

public enum Direction {
    UP, DOWN, LEFT, UP_LEFT, UP_RIGHT, DOWN_LEFT, DOWN_RIGHT, RIGHT
}
