package org.example;

import java.awt.*;

public class GameData {
    private Ball ball;
    private Ball ballEnemy;
    private Line line;
    public void update() {
        ball.move(5, Direction.RIGHT);

        line.extend(50, Direction.DOWN_RIGHT);

        ball.getBallRectangle();

        if(ballEnemy != null){
            ballEnemy.move(5, Direction.LEFT);

            if(ball.isCollided(ballEnemy.getBallRectangle())) {
                ballEnemy = null;
            }
        }


    }


    public void inicialize() {
        ball = new Ball(20, 20, 50, 50, Color.red);
        line = new Line(20, 20, 50, 50, Color.blue);
        ballEnemy = new Ball(500, 20, 50, 50, Color.green);
    }

    public Ball getBall() {
        return ball;
    }
    public Ball getBallEnemy(){
        return ballEnemy;
    }

    public Line getLine() {
        return line;
    }
}
